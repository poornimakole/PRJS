package com.psl.q3;

public class UninitializeStackException extends  Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public UninitializeStackException() {
		// TODO Auto-generated constructor stub
		super("Stack is not initialized...!!!");
	}
	

}
