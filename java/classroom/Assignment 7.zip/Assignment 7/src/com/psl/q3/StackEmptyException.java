package com.psl.q3;

public class StackEmptyException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public StackEmptyException() {
		// TODO Auto-generated constructor stub
		 super("Stack is Empty...!!!");
	}

}
