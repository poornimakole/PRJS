package com.psl.q3;

public class StackFullException extends Exception {
	
	  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public StackFullException() {
		// TODO Auto-generated constructor stub
		  super("Stack is Full...!!!");
	}
}
