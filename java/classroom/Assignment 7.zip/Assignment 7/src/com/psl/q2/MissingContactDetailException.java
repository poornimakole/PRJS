package com.psl.q2;

public class MissingContactDetailException extends Exception{
 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

public MissingContactDetailException() {
	// TODO Auto-generated constructor stub
	 super("Contact detail is missing....!!!");
}
 
}
