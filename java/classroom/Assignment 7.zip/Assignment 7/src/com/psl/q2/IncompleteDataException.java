package com.psl.q2;

public class IncompleteDataException extends Exception{
	
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

public IncompleteDataException() {
	// TODO Auto-generated constructor stub
	super("Mandatory data is incomplete....!!!");
}
}
