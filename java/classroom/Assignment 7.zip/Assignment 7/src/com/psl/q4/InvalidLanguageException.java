package com.psl.q4;

public class InvalidLanguageException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public InvalidLanguageException() {
		// TODO Auto-generated constructor stub
		super("Unspecified language....!!! ");
	}

}
