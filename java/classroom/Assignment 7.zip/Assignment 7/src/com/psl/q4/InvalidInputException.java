package com.psl.q4;

public class InvalidInputException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
  public InvalidInputException() {
	// TODO Auto-generated constructor stub
	  super("data is not in proper format....!!!1");
}
}
