package com.psl.q4;

public enum Language {
	hindi,english,marathi;

	public static boolean valueOf() {
		// TODO Auto-generated method stub
		return false;
	}
}
