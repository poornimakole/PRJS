package com.psl.q1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class SumCalculator {
	
	public double sumOfFirstNOdd(int n)
	{
		double sum=0;
		if(n<1)
		{
			throw new IllegalArgumentException("Number is not valid..!!!!");
		}
		else
		{
			for (int i = 0,j=1; i < n; i++,j=j+2) 
			{
				sum=sum+j;
			}
		}
		return sum;
	}
	public static void main(String[] args) {
		SumCalculator sc=new SumCalculator();
		BufferedReader br=null;
		br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the number:");
		int n;
		try {
			n = Integer.parseInt(br.readLine());
			double result=sc.sumOfFirstNOdd(n);
			System.out.println("Sum of First "+n+" Odd number is : "+result);
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
