package com.psl.q3;

public class InvalidAmountException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidAmountException(String str) {
		// TODO Auto-generated constructor stub
		super(str);
	}
}
