package com.psl.q3;

public class InsufficientFundsException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public InsufficientFundsException(String str) {
		// TODO Auto-generated constructor stub
		super(str);
	}

}
