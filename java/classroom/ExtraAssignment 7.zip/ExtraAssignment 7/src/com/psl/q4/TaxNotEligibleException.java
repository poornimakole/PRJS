package com.psl.q4;

public class TaxNotEligibleException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public TaxNotEligibleException(String str) {
		// TODO Auto-generated constructor stub
		super(str);
	}

}
