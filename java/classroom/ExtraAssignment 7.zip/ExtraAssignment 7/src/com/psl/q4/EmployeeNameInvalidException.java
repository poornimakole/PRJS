package com.psl.q4;

public class EmployeeNameInvalidException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public EmployeeNameInvalidException(String str) {
		// TODO Auto-generated constructor stub
		super(str);
	}

}
