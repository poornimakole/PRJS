package com.psl.q4;

public class CountryNotValidException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public CountryNotValidException(String str) {
		// TODO Auto-generated constructor stub
		super(str);
	}

}
