package com.psl.q2;

public class Customer {

	int customerId;	
	String customerName;	
	int isd_call_duration;
	double isd_per_min;
	int std_call_duration;
	double std_per_min;
	int local_call_duration;
	double local_per_min;
	
	
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public int getIsd_call_duration() {
		return isd_call_duration;
	}
	public void setIsd_call_duration(int isd_call_duration) {
		this.isd_call_duration = isd_call_duration;
	}
	public double getIsd_per_min() {
		return isd_per_min;
	}
	public void setIsd_per_min(double isd_per_min) {
		this.isd_per_min = isd_per_min;
	}
	public int getStd_call_duration() {
		return std_call_duration;
	}
	public void setStd_call_duration(int std_call_duration) {
		this.std_call_duration = std_call_duration;
	}
	public double getStd_per_min() {
		return std_per_min;
	}
	public void setStd_per_min(double std_per_min) {
		this.std_per_min = std_per_min;
	}
	public int getLocal_call_duration() {
		return local_call_duration;
	}
	public void setLocal_call_duration(int local_call_duration) {
		this.local_call_duration = local_call_duration;
	}
	public double getLocal_per_min() {
		return local_per_min;
	}
	public void setLocal_per_min(double local_per_min) {
		this.local_per_min = local_per_min;
	}

	
	
	
}
