package com.psl.q1;

public enum BookCategory {
	COMPUTER,ART,MATH,HORROR,FICTION,MUSIC;
}
