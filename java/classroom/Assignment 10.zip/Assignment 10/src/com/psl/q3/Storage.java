package com.psl.q3;

public class Storage {
	int num;
	
	public Storage() {
		// TODO Auto-generated constructor stub
	}
	public Storage(int num) {
		// TODO Auto-generated constructor stub
		this.num=num;
	}
	
	public int getNum() {
		return num;
	}
	
	public void setNum(int num) {
		this.num = num;
	}
	
	
}
