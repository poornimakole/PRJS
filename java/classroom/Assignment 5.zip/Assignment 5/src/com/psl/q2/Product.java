package com.psl.q2;

public class Product {
	String productId,productName;

	public Product() {
			
		}
	
	 public Product(String productId,String productName) {
	// TODO Auto-generated constructor stub
		 this.productId=productId;
		 this.productName=productName;
    }
	 

	
	


	

}
