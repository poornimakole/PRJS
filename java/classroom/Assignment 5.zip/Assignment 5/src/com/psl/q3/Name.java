package com.psl.q3;


public class Name {
	
	String firstname,surname;
	
	public void setFirstname(String firstName)
	{
		this.firstname=firstName;
	}
	public String getFirstname()
	{
		return firstname;
		
	}
	public void setSurname(String surname)
	{
		this.surname=surname;
	}
	public String getSurname()
	{
		return surname;
		
	}

}
