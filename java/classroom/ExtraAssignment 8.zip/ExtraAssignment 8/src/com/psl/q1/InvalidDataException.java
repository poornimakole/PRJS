package com.psl.q1;

public class InvalidDataException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public InvalidDataException(String str) {
		// TODO Auto-generated constructor stub
		super(str);
	}

}
