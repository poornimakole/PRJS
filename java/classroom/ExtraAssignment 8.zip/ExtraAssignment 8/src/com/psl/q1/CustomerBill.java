package com.psl.q1;

public class CustomerBill {

	String CustomerName;
	String travelMonth;
	double packages;
	double food;
	
	
	public String getCustomerName() {
		return CustomerName;
	}
	public void setCustomerName(String customerName) {
		CustomerName = customerName;
	}
	public String getTravelMonth() {
		return travelMonth;
	}
	public void setTravelMonth(String travelMonth) {
		this.travelMonth = travelMonth;
	}
	public double getPackages() {
		return packages;
	}
	public void setPackages(double packages) {
		this.packages = packages;
	}
	public double getFood() {
		return food;
	}
	public void setFood(double food) {
		this.food = food;
	}
	
	
	
}
