package com.psl.q1;

public class NoDataFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public NoDataFoundException(String str) {
		// TODO Auto-generated constructor stub
		super(str);
	}

}
