package com.psl.q2;

public class Person {

	int personID;
	String personName;
	long personTelephone;
	
	public int getPersonID() {
		return personID;
	}
	public void setPersonID(int personID) {
		this.personID = personID;
	}
	public String getPersonName() {
		return personName;
	}
	public void setPersonName(String personName) {
		this.personName = personName;
	}
	public long getPersonTelephone() {
		return personTelephone;
	}
	public void setPersonTelephone(long personTelephone) {
		this.personTelephone = personTelephone;
	}
	

	
}
