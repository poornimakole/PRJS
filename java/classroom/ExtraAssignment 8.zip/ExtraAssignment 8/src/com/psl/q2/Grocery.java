package com.psl.q2;

public enum Grocery {
	dals,pulses,flours,oil,rice,berries,nuts,dryfruits;
}
