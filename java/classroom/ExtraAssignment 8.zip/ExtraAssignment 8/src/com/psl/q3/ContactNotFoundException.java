package com.psl.q3;

public class ContactNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ContactNotFoundException() {
		// TODO Auto-generated constructor stub
		System.out.println(" contact not found...");
	}
}
