package com.psl.q7;

import java.util.ArrayList;
import java.util.List;

public class Client {

	public static void main(String[] args) {
		
		List<Integer> list=new ArrayList<Integer>();
		long t1=System.currentTimeMillis();
		for (int i = 0; i < 10000000; i++) {
			list.add(i);
		}
		long t2=System.currentTimeMillis();
		
		System.out.println("Response Time require for process is "+ (t2-t1)+"  msec");
	}
}
