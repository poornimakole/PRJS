$(function(){
    $.fn.move=function(){
        $(this).menu();
    }
})(jQuery);