$(function(){
    $.fn.styleIt=function(){
        $(this).css("color","red").css("fontSize","18px").css("backgroundColor","grey");
    }
})(jQuery);