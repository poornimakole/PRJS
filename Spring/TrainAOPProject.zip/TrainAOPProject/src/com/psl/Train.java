package com.psl;

public class Train {

	public void trainRunOnTime()
	{
		System.out.println("train run on time....");
	}
}
