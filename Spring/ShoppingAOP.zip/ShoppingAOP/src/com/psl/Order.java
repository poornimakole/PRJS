package com.psl;

public class Order {
	
	public void placeOrder(){
		System.out.println("user added fabric for sofa to cart...");
		System.out.println("user placed order.....");
	}

}
