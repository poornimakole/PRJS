import { Component } from '@angular/core';

@Component({
    selector: 'error',
    template:`
    <h4>Page Not Found</h4>
    `
})

export class PageNotFoundComponent {
    constructor() { }
}